create function hm_drop_table(tablename character varying) returns void
    language plpgsql
as
$$
DECLARE
	table_exists int4;
BEGIN
	SELECT into table_exists count(*) from pg_class where relname = tablename::name;
	if table_exists > 0 then
		execute 'DROP TABLE ' || tablename;
	end if;
END;
$$;

alter function hm_drop_table(varchar) owner to postgres;

